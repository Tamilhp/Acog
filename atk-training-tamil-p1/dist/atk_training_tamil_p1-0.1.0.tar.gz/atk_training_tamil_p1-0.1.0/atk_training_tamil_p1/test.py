import numpy
a = [[2],[1], [1]]