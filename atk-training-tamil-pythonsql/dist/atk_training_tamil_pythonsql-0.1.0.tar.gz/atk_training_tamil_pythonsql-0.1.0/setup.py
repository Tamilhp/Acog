# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['atk_training_tamil_pythonsql']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.5.2,<2.0.0', 'typer>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['atk-training-tamil-bulkload = '
                     'atk_training_tamil_pythonsql.bulk_load_decorator:main']}

setup_kwargs = {
    'name': 'atk-training-tamil-pythonsql',
    'version': '0.1.0',
    'description': '',
    'long_description': '---\nproject_name: atk-training-tamil-pythonsql\nshort_description: This short description needs to be edited by tamil\ntags: []\ncategory: tech\nlong_description: >\n  This is the long descripption to be edited by tamil\n  Created on Wed Dec 14 17:48:14 IST 2022\n  Built with poetry\n---\n\nTODO: Fix the following\n# Purpose\nHere three line description about how to use this code, the context.\n\n# Installation\nHow do we use install the code, library or whatever. What prereqs are needed\n\n# How to use it\nHow do I use it? Examples, if needed. \n\n# Related information\nReferences etc if needed.\n',
    'author': 'Tamil Selvan',
    'author_email': 'tamil@aganitha.ai',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
