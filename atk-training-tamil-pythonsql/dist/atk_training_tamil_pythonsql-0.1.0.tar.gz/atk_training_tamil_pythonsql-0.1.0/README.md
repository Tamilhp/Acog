---
project_name: atk-training-tamil-pythonsql
short_description: This short description needs to be edited by tamil
tags: []
category: tech
long_description: >
  This is the long descripption to be edited by tamil
  Created on Wed Dec 14 17:48:14 IST 2022
  Built with poetry
---

TODO: Fix the following
# Purpose
Here three line description about how to use this code, the context.

# Installation
How do we use install the code, library or whatever. What prereqs are needed

# How to use it
How do I use it? Examples, if needed. 

# Related information
References etc if needed.
